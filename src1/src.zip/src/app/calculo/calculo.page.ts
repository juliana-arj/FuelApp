import { Component, OnInit, ViewChild } from '@angular/core'; // <-- 1. Adicione ViewChild
import { IonContent, ToastController } from '@ionic/angular'; // <-- Importe o ToastController
import { FormsModule } from '@angular/forms';
import { Storage } from '@ionic/storage-angular';

export interface Abastecimento {
  id: number;
  data: string;
  quilometragem: number;
  litros: number;
  valor: number | null;
  combustivel: string;
  consumoMedio: number;
  custoPorKm: number | null;
}

@Component({
  selector: 'app-calculo',
  templateUrl: './calculo.page.html',
  styleUrls: ['./calculo.page.scss'],
  standalone: false,

})
export class CalculoPage implements OnInit {

  @ViewChild(IonContent) content!: IonContent;

  // Propriedades para capturar os dados do formulário
  // Por enquanto, usaremos apenas o necessário para o cálculo simples:
  quilometragemPercorrida: number | null = null; // Vamos simplificar para KM percorrida no primeiro momento
  litrosAbastecidos: number | null = null;
  valorPago: number | null = null; // Opcional

  // Propriedades para exibir os resultados
  consumoMedio: string = '—'; // km/l
  custoPorKm: string = '—'; // R$

  dataAbastecimento: string = ''; // Para capturar a data
  tipoCombustivel: string = ''; // Para capturar a seleção (gasolina, etanol, diesel)

  calculoRealizado: boolean = false;

  constructor(private toastCtrl: ToastController, private storage: Storage) { }

  async ngOnInit() {
    // 3. Inicializar o Storage (Obrigatório antes de usar)
    await this.storage.create();
  }

  get isCalculoDisabled(): boolean {
    // Retorna TRUE se qualquer um dos campos obrigatórios NÃO estiver preenchido/válido
    return (
      this.quilometragemPercorrida === null ||
      this.quilometragemPercorrida <= 0 ||
      this.litrosAbastecidos === null ||
      this.litrosAbastecidos <= 0 ||
      this.dataAbastecimento === '' ||
      this.tipoCombustivel === ''
    );
  }

  // Método que será chamado pelo botão "Calcular"
  async calcularConsumo(): Promise<void> { // <-- O método deve ser 'async' para o 'await' do scroll

    // 1. Verificar se os campos obrigatórios estão preenchidos
    if (this.isCalculoDisabled) {
      // ❌ Oculta o cartão de resultado se o cálculo for bloqueado
      this.calculoRealizado = false;
      // Se o botão está desabilitado, o usuário não deveria chegar aqui, 
      // mas se chegar (por manipulação ou outro bug), paramos:
      // this.mostrarAlerta('Preencha os campos obrigatórios!'); 
      this.consumoMedio = '—';
      this.custoPorKm = '—';
      return;
    }

    // 2. Lógica do Cálculo de Consumo Médio
    // Consumo (km/l) = KM percorrida / Litros abastecidos
    const consumo = this.quilometragemPercorrida! / this.litrosAbastecidos!;
    this.consumoMedio = consumo.toFixed(2);

    // 3. Lógica do Cálculo de Custo por Km (se o valor for fornecido)
    if (this.valorPago !== null && this.valorPago > 0 && this.quilometragemPercorrida! > 0) {
      const custo = this.valorPago / this.quilometragemPercorrida!;
      this.custoPorKm = custo.toFixed(2);
    } else {
      this.custoPorKm = '—';
    }

    this.calculoRealizado = true;

    // ✅ ROLAGEM AUTOMÁTICA
    // É importante esperar um pequeno momento (setTimeout) para que o *ngIf
    // termine de renderizar a div de resultado antes de rolar.
    setTimeout(async () => {
      // Rola suavemente ('true') para o final da página
      await this.content.scrollToBottom(500); // 500ms é uma boa velocidade
    }, 50); // Atraso de 50ms para garantir a renderização
  }

  // =========================================================================
  // ✅ 1. NOVO MÉTODO: SALVAR ABASTECIMENTO
  // =========================================================================
  async salvarAbastecimento(): Promise<void> {

    if (this.isCalculoDisabled || this.consumoMedio === '—') {
      this.mostrarAlerta('Calcule o consumo primeiro.', 'warning' as any);
      return;
    }

    const novoAbastecimento: Abastecimento = {
        id: new Date().getTime(), // ID baseado no timestamp
        data: this.dataAbastecimento,
        quilometragem: this.quilometragemPercorrida!,
        litros: this.litrosAbastecidos!,
        consumoMedio: parseFloat(this.consumoMedio),
        combustivel: this.tipoCombustivel,
        
        // Valores opcionais/calculados
        valor: this.valorPago,
        custoPorKm: this.custoPorKm === '—' ? null : parseFloat(this.custoPorKm),
    };
    // ---------------------------------------------------------------------

    try {
        // 1. BUSCAR a lista de abastecimentos existente (USANDO o serviço injetado)
        const value = await this.storage.get('abastecimentos'); 
        let listaAbastecimentos: Abastecimento[] = value || [];

        // 2. ADICIONAR e SALVAR
        listaAbastecimentos.push(novoAbastecimento);
        
        // Opcional: Ordenar a lista do mais novo para o mais antigo (ID maior)
        listaAbastecimentos.sort((a, b) => b.id - a.id); 

        // 3. SALVAR a lista atualizada de volta
        await this.storage.set('abastecimentos', listaAbastecimentos);

        // 4. Feedback e Limpeza (Apenas dentro do TRY)
        this.mostrarAlerta('Abastecimento salvo com sucesso!', 'dark' as any);
        this.resetarFormulario();
        
    } catch (error) {
        this.mostrarAlerta('Erro ao salvar abastecimento.', 'danger');
        console.error('Erro de Storage:', error);
    }
    
    // ❌ REMOVA ESTAS LINHAS: Eram chamadas duplicadas fora do try/catch
    // this.mostrarAlerta('Abastecimento salvo com sucesso!', 'success');
    // this.resetarFormulario();
  }


  // =========================================================================
  // ✅ 2. NOVO MÉTODO: RESETAR O FORMULÁRIO
  // =========================================================================
  private resetarFormulario(): void {
    // A. Esconde a div de resultado
    this.calculoRealizado = false;

    // B. Limpa os valores dos inputs
    this.dataAbastecimento = '';
    this.quilometragemPercorrida = null;
    this.litrosAbastecidos = null;
    this.valorPago = null;
    this.tipoCombustivel = '';

    // C. Limpa os valores de resultado (para a próxima vez)
    this.consumoMedio = '—';
    this.custoPorKm = '—';
  }


  // Método de Alerta (Toast) - (Se você ainda não o adicionou)
  async mostrarAlerta(mensagem: string, cor: 'danger' | 'success' | 'warning' = 'success') {
    const toast = await this.toastCtrl.create({
      message: mensagem,
      duration: 3000,
      position: 'bottom',
      color: cor
    });
    toast.present();
  }

}
