// historico.page.ts

import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage-angular'; // Para buscar os dados
import { ToastController, AlertController} from '@ionic/angular'; // Para feedback

// ✅ REPETIR A INTERFACE (ou importar se estiver em um arquivo separado)
export interface Abastecimento {
  id: number;
  data: string;
  quilometragem: number;
  litros: number;
  valor: number | null;
  combustivel: string;
  consumoMedio: number;
  custoPorKm: number | null;
}
// -----------------------------------------------------------------


@Component({
  selector: 'app-historico',
  templateUrl: './historico.page.html',
  styleUrls: ['./historico.page.scss'],
  standalone: false, // Assumindo que você está usando módulos
})
export class HistoricoPage implements OnInit {

  // ✅ PROPRIEDADE PARA ARMAZENAR OS REGISTROS LIDOS
  historico: Abastecimento[] = [];
  
  // Flag para mostrar uma mensagem de "Histórico Vazio"
  historicoCarregado: boolean = false; 

  constructor(
    private storage: Storage, 
    private toastCtrl: ToastController,
    private alertCtrl: AlertController
  ) { }

  async ngOnInit() {
    // Inicializa o Storage (sempre necessário)
    await this.storage.create(); 
    
    // Carrega os dados assim que a página for iniciada
    this.carregarHistorico();
  }
  
  // Método executado toda vez que a página é acessada
  ionViewWillEnter() {
    this.carregarHistorico();
  }


  // =========================================================================
  // ✅ MÉTODO: CARREGAR DADOS DO STORAGE
  // =========================================================================
  async carregarHistorico(): Promise<void> {
    try {
      // 1. Buscar a lista salva
      const value = await this.storage.get('abastecimentos');
      
      // 2. Se houver valor, atribuir ao array, senão, usar array vazio
      let listaAbastecimentos: Abastecimento[] = value || [];

      // 3. Ordenar a lista (garantir que o mais novo esteja no topo, por data/id)
      listaAbastecimentos.sort((a, b) => b.id - a.id); 
      
      this.historico = listaAbastecimentos;

    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
      this.mostrarAlerta('Erro ao carregar histórico.', 'danger');
    } finally {
      this.historicoCarregado = true; // Indica que a tentativa de carga terminou
    }
  }


  // Método de Alerta (Toast) (copiado do calculo.page.ts para consistência)
  async mostrarAlerta(mensagem: string, cor: 'danger' | 'success' | 'warning' | any = 'success') {
    const toast = await this.toastCtrl.create({
      message: mensagem,
      duration: 3000,
      position: 'bottom',
      color: cor
    });
    toast.present();
  }

  // =========================================================================
  // ✅ NOVO MÉTODO 1: CONFIRMAR E DELETAR ABASTECIMENTO (Chama o alerta)
  // =========================================================================
  async confirmarExclusao(id: number): Promise<void> {
    const alert = await this.alertCtrl.create({
      header: 'Confirmar Exclusão',
      message: 'Tem certeza que deseja excluir este registro? Esta ação é irreversível.',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'Excluir',
          cssClass: 'danger',
          // Ao confirmar, chama o método de deleção real
          handler: () => {
            this.deletarAbastecimento(id); 
          },
        },
      ],
    });

    await alert.present();
  }

  // =========================================================================
  // ✅ NOVO MÉTODO 2: DELETAR ABASTECIMENTO (Ação real no Storage)
  // =========================================================================
  async deletarAbastecimento(id: number): Promise<void> {
    try {
      // 1. Obter a lista atual
      const value = await this.storage.get('abastecimentos');
      let listaAbastecimentos: Abastecimento[] = value || [];

      // 2. Filtrar a lista: cria uma nova lista SEM o item com o ID
      const listaAtualizada = listaAbastecimentos.filter(item => item.id !== id);

      // 3. Salvar a nova lista no Storage
      await this.storage.set('abastecimentos', listaAtualizada);

      // 4. Atualizar a lista localmente para refletir a mudança na tela
      this.historico = listaAtualizada;
      
      // 5. Feedback de sucesso
      this.mostrarAlerta('Registro excluído com sucesso!', 'dark' as any); 

    } catch (error) {
      this.mostrarAlerta('Erro ao excluir registro.', 'danger');
      console.error('Erro ao deletar do Storage:', error);
    }
  }
  
}