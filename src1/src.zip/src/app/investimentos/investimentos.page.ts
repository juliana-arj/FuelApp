import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investimentos',
  templateUrl: './investimentos.page.html',
  styleUrls: ['./investimentos.page.scss'],
    standalone: false,

})
export class InvestimentosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
