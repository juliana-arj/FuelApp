// graficos.page.ts

import { Component, OnInit, ViewChild } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { ToastController } from '@ionic/angular';
// ✅ Importar as ferramentas necessárias do Chart.js
import { Chart, registerables } from 'chart.js';

// Importar a interface Abastecimento (assumindo que está definida no seu projeto)
export interface Abastecimento {
  id: number;
  data: string;
  quilometragem: number;
  litros: number;
  valor: number | null;
  combustivel: string;
  consumoMedio: number;
  custoPorKm: number | null;
}

// ✅ Registrar todos os componentes do Chart.js (essencial!)
Chart.register(...registerables);

@Component({
  selector: 'app-graficos',
  templateUrl: './graficos.page.html',
  styleUrls: ['./graficos.page.scss'],
  standalone: false,
})
export class GraficosPage implements OnInit {

  // ✅ Referências para os elementos <canvas> no HTML
  @ViewChild('lineCanvas') lineCanvas: any;
  @ViewChild('barCanvas') barCanvas: any;

  // Variáveis para armazenar as instâncias dos gráficos
  lineChart: any;
  barChart: any;

  // Lista de abastecimentos
  abastecimentos: Abastecimento[] = [];


  constructor(
    private storage: Storage,
    private toastCtrl: ToastController
  ) { }

  async ngOnInit() {
    await this.storage.create();
    // ✅ Carrega os dados na inicialização
    await this.carregarDados();
  }

  // Hook do Ionic: garante que os gráficos sejam redesenhados ao entrar na página
  ionViewDidEnter() {
    this.desenharGraficos();
  }


  async carregarDados(): Promise<void> {
    try {
      const value = await this.storage.get('abastecimentos');
      this.abastecimentos = value || [];

      // Ordena do mais antigo para o mais novo (necessário para gráfico de linha)
      this.abastecimentos.sort((a, b) => a.id - b.id);

      // Chama o desenho após o carregamento dos dados
      this.desenharGraficos();

    } catch (error) {
      console.error('Erro ao carregar dados para gráficos:', error);
      this.mostrarAlerta('Erro ao carregar dados.', 'danger');
    }
  }

  // =========================================================================
  // ✅ MÉTODO PRINCIPAL DE DESENHO
  // =========================================================================
  desenharGraficos() {
    if (!this.lineCanvas || !this.barCanvas || this.abastecimentos.length === 0) {
      // Evita tentar desenhar se os elementos ainda não existirem ou se não houver dados
      return;
    }

    // 1. Destroi gráficos anteriores para evitar duplicidade
    if (this.lineChart) this.lineChart.destroy();
    if (this.barChart) this.barChart.destroy();

    // 2. Chama a criação dos gráficos individuais
    this.criarGraficoLinhaConsumo();
    this.criarGraficoComparativoCombustivel();
  }

  // =========================================================================
  // ✅ GRÁFICO 1: EVOLUÇÃO DO CONSUMO (LINHA)
  // =========================================================================
  criarGraficoLinhaConsumo() {
    // Labels (Datas formatadas)
    const labels = this.abastecimentos.map(item => new Date(item.data).toLocaleDateString('pt-BR'));
    // Dados (Consumo Médio)
    const data = this.abastecimentos.map(item => item.consumoMedio);

    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Consumo Médio (km/l)',
          data: data,
          borderColor: 'rgb(255, 99, 132)', // Cor principal do seu tema (exemplo)
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          tension: 0.3, // Suaviza a linha
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false, // Permite que ele se ajuste ao card-content
      }
    });
  }

  // =========================================================================
  // ✅ GRÁFICO 2: COMPARATIVO DE COMBUSTÍVEL (BARRAS ou ROSCA)
  // Vamos usar o consumo médio por tipo de combustível (Agregação)
  // =========================================================================
  criarGraficoComparativoCombustivel() {
    const dadosAgregados = this.abastecimentos.reduce((acc, item) => {
      if (!acc[item.combustivel]) {
        acc[item.combustivel] = { totalConsumo: 0, count: 0 };
      }
      acc[item.combustivel].totalConsumo += item.consumoMedio;
      acc[item.combustivel].count += 1;
      return acc;
    }, {} as Record<string, { totalConsumo: number, count: number }>);

    const labels = Object.keys(dadosAgregados);
    const mediaConsumo = labels.map(key => dadosAgregados[key].totalConsumo / dadosAgregados[key].count);

    const cores = labels.map(comb => {
      if (comb === 'gasolina') return 'rgb(75, 192, 192)'; // Verde/Água
      if (comb === 'etanol') return 'rgb(255, 159, 64)'; // Laranja
      if (comb === 'diesel') return 'rgb(54, 162, 235)'; // Azul
      return 'rgb(201, 203, 207)'; // Cinza padrão
    });


    this.barChart = new Chart(this.barCanvas.nativeElement, {
      type: 'bar', // Tipo barra para ver a diferença de consumo
      data: {
        labels: labels.map(l => l.charAt(0).toUpperCase() + l.slice(1)), // Capitaliza a primeira letra
        datasets: [{
          label: 'Média Consumo (km/l)',
          data: mediaConsumo,
          backgroundColor: cores,
          borderColor: cores,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }

  // Método de Alerta (Toast) (manter para feedback)
  async mostrarAlerta(mensagem: string, cor: 'danger' | 'success' | 'warning' | any = 'success') {
    const toast = await this.toastCtrl.create({
      message: mensagem,
      duration: 3000,
      position: 'bottom',
      color: cor
    });
    toast.present();
  }
}