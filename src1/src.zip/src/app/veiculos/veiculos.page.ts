import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-veiculos',
  templateUrl: './veiculos.page.html',
  styleUrls: ['./veiculos.page.scss'],
  standalone:false,
})
export class VeiculosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
