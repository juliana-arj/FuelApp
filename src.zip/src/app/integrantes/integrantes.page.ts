import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-integrantes',
  templateUrl: './integrantes.page.html',
  styleUrls: ['./integrantes.page.scss'],
  standalone:false,
})
export class IntegrantesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
